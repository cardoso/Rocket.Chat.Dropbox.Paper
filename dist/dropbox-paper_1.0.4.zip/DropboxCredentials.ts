export class DropboxCredentials {
    static token = 'LcVxWWKgzLAAAAAAAAADKyC_zTPIXcTBtucGrmzyyhJrlBtYUlaGIvVdV0TuMa2b';
};